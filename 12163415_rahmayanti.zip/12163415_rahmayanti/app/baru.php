<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class baru extends Model
{
    //
}
